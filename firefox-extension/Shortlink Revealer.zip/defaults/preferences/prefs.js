pref("extensions.ShortlinkRevealer.boolpref", false);
pref("extensions.ShortlinkRevealer.intpref", 0);
pref("extensions.ShortlinkRevealer.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.ShortLyRevealer.description", "chrome://ShortlinkRevealer/locale/overlay.properties");
